#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar 24 14:53:16 2022

@author: michellehitch_snhu
"""

from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """CRUD operations for Animal collection in Mongodatabase"""
    #Initializes MongoClient
    def __init__(self, username, password):
        self.client = MongoClient('mongodb://%s:%s@localhost:47352/ACC' % (username, password))
        self.database = self.client['ACC'] 
        #Implement create method
    def create(self, data):
        if data is not None:
            return self.database.animals.insert_one(data)    
        else:
            raise Exception("Nothing to save, because data parameter is empty")
        #Implement read method
    def read(self,criteria=None):
        if criteria:
            {'_id':False} 
            data = self.database.animals.find(criteria,{"_id":False})
        else:
            data = self.database.animals.find( {} , {"_id":False})
        return data
            #Implement update method
    def update(self, data, update_type, update_data):
        if self.database.animals.find(data) is not None:
            return self.database.animals.update_one(data,{"$set":{update_type : update_data}})
        else:
            raise Exception("Nothing to update, because data parameter is empty")
            #Implement delete method
    def delete(self, data):
        if self.database.animals.find(data) is not None:
            self.database.animals.delete_many(data)
        else:
            raise Exception("Nothing to delete, because data parameter is empty")
            
    def RescueTypeWater(self):
        Rescue = self.database.animals.find({
    "breed" : { "$in": ["Labrador Retriever Mix", "Chesapeake Bay Retriever", "Newfoundland"] },
    "sex_upon_outcome" : { "$in": ["Intact Female"] },"age_upon_outcome_in_weeks" : {"$gt" : 26.0, "$lt" : 156.0}},{"_id":False})
        return Rescue
    
    def RescueTypeMountainWilderness(self):
        Rescue = self.database.animals.find({
    "breed" : { "$in": ["German Shepherd", "Alaskan Malamute", "Old English Sheepdog", "Siberian Husky",
"Rottweiler"] },
    "sex_upon_outcome" : { "$in": ["Intact Male"] },"age_upon_outcome_in_weeks" : {"$gt" : 26.0, "$lt" : 156.0}},{"_id":False})
        return Rescue
    
    def RescueTypeDisasterTracking(self):
        Rescue = self.database.animals.find({
    "breed" : { "$in": ["Doberman Pinscher", "German Shepherd", "Golden Retriever", "Bloodhound", "Rottweiler"] },
    "sex_upon_outcome" : { "$in": ["Intact Male"] },"age_upon_outcome_in_weeks" : {"$gt" : 20.0, "$lt" : 300.0}},{"_id":False})
        return Rescue